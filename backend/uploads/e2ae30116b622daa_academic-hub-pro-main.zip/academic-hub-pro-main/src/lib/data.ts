export type Domain = {
  id: string;
  slug: string;
  name: string;
  category: string;
  short: string;
  description: string;
  price: number;
  resourceCount: number;
  sizeGB: number;
  files: { name: string; type: string; size: string }[];
  benefits: string[];
  accent: string;
};

export const DOMAINS: Domain[] = [
  {
    id: "d-aiml",
    slug: "ai-machine-learning",
    name: "AI & Machine Learning",
    category: "Engineering",
    short: "Neural networks, Python implementations, datasets and viva banks.",
    description:
      "A comprehensive bundle covering supervised and unsupervised learning, deep learning architectures, training pipelines, and final-year project documentation reviewed by industry mentors.",
    price: 49,
    resourceCount: 128,
    sizeGB: 15.4,
    files: [
      { name: "01_Final_Project_Report.pdf", type: "PDF", size: "12.4 MB" },
      { name: "02_Implementation_Source.zip", type: "ZIP", size: "184 MB" },
      { name: "03_Viva_Preparation_Guide.docx", type: "DOCX", size: "2.1 MB" },
      { name: "04_Dataset_Presentation.pptx", type: "PPTX", size: "8.7 MB" },
      { name: "05_Research_References.pdf", type: "PDF", size: "5.3 MB" },
    ],
    benefits: ["Final Year Projects", "Mini Projects", "Notes", "PPTs", "Viva Questions", "Documentation"],
    accent: "oklch(0.55 0.18 260)",
  },
  {
    id: "d-cyber",
    slug: "cyber-security",
    name: "Cyber Security",
    category: "Engineering",
    short: "Penetration testing reports, encryption notes, and security audits.",
    description:
      "Defensive and offensive security materials including network protocols, ethical hacking labs, and audit templates suitable for capstone projects.",
    price: 45,
    resourceCount: 96,
    sizeGB: 9.8,
    files: [
      { name: "Pentest_Report_Template.docx", type: "DOCX", size: "3.2 MB" },
      { name: "Network_Security_Notes.pdf", type: "PDF", size: "18.4 MB" },
      { name: "Cryptography_Slides.pptx", type: "PPTX", size: "11.2 MB" },
    ],
    benefits: ["Pentest Reports", "Lab Manuals", "Notes", "Viva Q&A", "Case Studies", "Documentation"],
    accent: "oklch(0.55 0.18 25)",
  },
  {
    id: "d-cloud",
    slug: "cloud-computing",
    name: "Cloud Computing",
    category: "Engineering",
    short: "AWS, Azure setup guides and infrastructure as code templates.",
    description:
      "Architecture diagrams, cost optimization notes, and ready-to-deploy IaC templates spanning AWS, Azure and GCP.",
    price: 39,
    resourceCount: 84,
    sizeGB: 6.2,
    files: [
      { name: "AWS_Architecture.pdf", type: "PDF", size: "9.1 MB" },
      { name: "Terraform_Templates.zip", type: "ZIP", size: "42 MB" },
    ],
    benefits: ["Projects", "IaC Templates", "Notes", "PPTs", "Viva Questions", "Diagrams"],
    accent: "oklch(0.6 0.14 220)",
  },
  {
    id: "d-iot",
    slug: "iot",
    name: "Internet of Things",
    category: "Engineering",
    short: "Embedded projects, sensor wiring guides, and firmware code.",
    description: "End-to-end IoT projects with Arduino, ESP32 and Raspberry Pi, including circuits and reports.",
    price: 35,
    resourceCount: 64,
    sizeGB: 4.4,
    files: [{ name: "IoT_Projects_Bundle.zip", type: "ZIP", size: "320 MB" }],
    benefits: ["Hardware Projects", "Firmware Source", "Wiring Diagrams", "PPTs", "Viva Q&A", "Reports"],
    accent: "oklch(0.65 0.15 140)",
  },
  {
    id: "d-data",
    slug: "data-science",
    name: "Data Science",
    category: "Engineering",
    short: "EDA notebooks, dashboards, and statistical project reports.",
    description: "Real-world datasets, Jupyter notebooks, dashboards in Power BI and Tableau, and analytical reports.",
    price: 45,
    resourceCount: 110,
    sizeGB: 12.1,
    files: [{ name: "DataScience_Projects.zip", type: "ZIP", size: "510 MB" }],
    benefits: ["Notebooks", "Datasets", "Dashboards", "Notes", "Viva Q&A", "Case Studies"],
    accent: "oklch(0.6 0.16 300)",
  },
  {
    id: "d-mba",
    slug: "mba",
    name: "MBA Bundle",
    category: "Management",
    short: "Case studies, financial models, marketing strategies and templates.",
    description: "Strategy, finance, marketing, HR — full coursework, capstone reports and editable PPT templates.",
    price: 59,
    resourceCount: 210,
    sizeGB: 18.6,
    files: [{ name: "MBA_MasterPack.zip", type: "ZIP", size: "1.8 GB" }],
    benefits: ["Case Studies", "Financial Models", "Strategy Notes", "PPT Templates", "Viva Q&A", "Reports"],
    accent: "oklch(0.5 0.14 60)",
  },
  {
    id: "d-bba",
    slug: "bba",
    name: "BBA Resources",
    category: "Management",
    short: "Coursework, project reports and viva prep for undergraduates.",
    description: "Three-year syllabus aligned notes, summer internship report templates and project documentation.",
    price: 35,
    resourceCount: 88,
    sizeGB: 5.4,
    files: [{ name: "BBA_Bundle.zip", type: "ZIP", size: "420 MB" }],
    benefits: ["Notes", "Internship Reports", "Projects", "PPTs", "Viva Q&A", "Templates"],
    accent: "oklch(0.6 0.12 50)",
  },
  {
    id: "d-bcom",
    slug: "b-com",
    name: "B.Com Studies",
    category: "Commerce",
    short: "Accountancy, taxation and finance notes plus reports.",
    description: "Subject-wise compiled notes, accounting practice sheets, and final-year project documentation.",
    price: 29,
    resourceCount: 72,
    sizeGB: 3.2,
    files: [{ name: "BCom_Bundle.zip", type: "ZIP", size: "260 MB" }],
    benefits: ["Subject Notes", "Practice Sheets", "Projects", "PPTs", "Viva Q&A", "Case Law"],
    accent: "oklch(0.55 0.14 160)",
  },
  {
    id: "d-mcom",
    slug: "m-com",
    name: "M.Com Studies",
    category: "Commerce",
    short: "Advanced accounting, audit and research methodology.",
    description: "Postgraduate-level notes, dissertation templates and research methodology guides.",
    price: 39,
    resourceCount: 80,
    sizeGB: 4.1,
    files: [{ name: "MCom_Bundle.zip", type: "ZIP", size: "310 MB" }],
    benefits: ["Notes", "Dissertation Templates", "Research", "PPTs", "Viva Q&A", "Case Studies"],
    accent: "oklch(0.5 0.13 170)",
  },
  {
    id: "d-finance",
    slug: "commerce-finance",
    name: "Commerce & Finance",
    category: "Commerce",
    short: "Equity research, valuation models and finance projects.",
    description: "DCF models, equity research templates, and capstone-ready finance projects.",
    price: 49,
    resourceCount: 95,
    sizeGB: 6.8,
    files: [{ name: "Finance_Bundle.zip", type: "ZIP", size: "460 MB" }],
    benefits: ["Valuation Models", "Equity Research", "Projects", "PPTs", "Viva Q&A", "Templates"],
    accent: "oklch(0.55 0.15 90)",
  },
  {
    id: "d-psych",
    slug: "psychology",
    name: "Psychology",
    category: "Humanities",
    short: "Theory notes, dissertation guides and case study templates.",
    description: "Subject-wise psychology notes, APA-style dissertation templates and clinical case studies.",
    price: 35,
    resourceCount: 70,
    sizeGB: 3.8,
    files: [{ name: "Psych_Bundle.zip", type: "ZIP", size: "280 MB" }],
    benefits: ["Theory Notes", "Case Studies", "Dissertation", "PPTs", "Viva Q&A", "Research"],
    accent: "oklch(0.6 0.13 340)",
  },
  {
    id: "d-history",
    slug: "history",
    name: "History",
    category: "Humanities",
    short: "Timelines, source readings, and historiography notes.",
    description: "Carefully compiled timelines, primary source extracts and dissertation references.",
    price: 25,
    resourceCount: 58,
    sizeGB: 2.6,
    files: [{ name: "History_Bundle.zip", type: "ZIP", size: "180 MB" }],
    benefits: ["Notes", "Timelines", "Sources", "PPTs", "Viva Q&A", "Reports"],
    accent: "oklch(0.55 0.14 50)",
  },
  {
    id: "d-polsci",
    slug: "political-science",
    name: "Political Science",
    category: "Humanities",
    short: "Political theory, comparative politics and IR notes.",
    description: "Theory-driven notes, comparative politics frameworks and international relations briefs.",
    price: 29,
    resourceCount: 64,
    sizeGB: 3.0,
    files: [{ name: "PolSci_Bundle.zip", type: "ZIP", size: "220 MB" }],
    benefits: ["Theory Notes", "Briefs", "Case Studies", "PPTs", "Viva Q&A", "Research"],
    accent: "oklch(0.5 0.14 280)",
  },
  {
    id: "d-arts",
    slug: "arts-humanities",
    name: "Arts & Humanities",
    category: "Humanities",
    short: "Cross-disciplinary essays, literature notes and project material.",
    description: "Literature notes, essay templates, and interdisciplinary humanities projects.",
    price: 29,
    resourceCount: 60,
    sizeGB: 2.8,
    files: [{ name: "Arts_Bundle.zip", type: "ZIP", size: "200 MB" }],
    benefits: ["Essays", "Literature Notes", "Projects", "PPTs", "Viva Q&A", "Research"],
    accent: "oklch(0.6 0.13 20)",
  },
];

export const CATEGORIES = ["All", "Engineering", "Management", "Commerce", "Humanities"];

export type Purchase = {
  id: string;
  domainId: string;
  domainName: string;
  buyer: string;
  mobile: string;
  college: string;
  email?: string;
  amount: number;
  status: "paid" | "pending" | "failed";
  date: string;
  transactionId: string;
};

const MOCK_PURCHASES: Purchase[] = [
  {
    id: "p1",
    domainId: "d-aiml",
    domainName: "AI & Machine Learning",
    buyer: "Ananya Sharma",
    mobile: "9812345678",
    college: "IIT Delhi",
    email: "ananya@iitd.ac.in",
    amount: 49,
    status: "paid",
    date: "2026-06-14",
    transactionId: "TXN-8821",
  },
  {
    id: "p2",
    domainId: "d-mba",
    domainName: "MBA Bundle",
    buyer: "Rahul Verma",
    mobile: "9988776655",
    college: "IIM Bangalore",
    amount: 59,
    status: "paid",
    date: "2026-06-13",
    transactionId: "TXN-8820",
  },
  {
    id: "p3",
    domainId: "d-cyber",
    domainName: "Cyber Security",
    buyer: "Priya Nair",
    mobile: "9876543210",
    college: "NIT Trichy",
    email: "priya@nitt.edu",
    amount: 45,
    status: "paid",
    date: "2026-06-12",
    transactionId: "TXN-8819",
  },
  {
    id: "p4",
    domainId: "d-data",
    domainName: "Data Science",
    buyer: "Kabir Singh",
    mobile: "9123456789",
    college: "BITS Pilani",
    amount: 45,
    status: "pending",
    date: "2026-06-11",
    transactionId: "TXN-8818",
  },
  {
    id: "p5",
    domainId: "d-cloud",
    domainName: "Cloud Computing",
    buyer: "Sneha Iyer",
    mobile: "9090909090",
    college: "VIT Vellore",
    email: "sneha@vit.ac.in",
    amount: 39,
    status: "paid",
    date: "2026-06-10",
    transactionId: "TXN-8817",
  },
];

export function getDomainBySlug(slug: string) {
  return DOMAINS.find((d) => d.slug === slug);
}
export function getDomainById(id: string) {
  return DOMAINS.find((d) => d.id === id);
}

export function getPurchases(): Purchase[] {
  if (typeof window === "undefined") return MOCK_PURCHASES;
  const stored = localStorage.getItem("pv-purchases");
  const extra: Purchase[] = stored ? JSON.parse(stored) : [];
  return [...extra, ...MOCK_PURCHASES];
}
export function addPurchase(p: Purchase) {
  const stored = localStorage.getItem("pv-purchases");
  const extra: Purchase[] = stored ? JSON.parse(stored) : [];
  localStorage.setItem("pv-purchases", JSON.stringify([p, ...extra]));
}

/* Admin mock auth */
export function adminLogin(email: string, password: string) {
  const users = JSON.parse(localStorage.getItem("pv-admins") || "[]");
  const u = users.find((u: any) => u.email === email && u.password === password);
  if (!u && !(email === "admin@projectverse.com" && password === "admin123")) return false;
  localStorage.setItem(
    "pv-admin-session",
    JSON.stringify({ email, name: u?.name ?? "Admin" }),
  );
  return true;
}
export function adminRegister(name: string, email: string, password: string) {
  const users = JSON.parse(localStorage.getItem("pv-admins") || "[]");
  if (users.find((u: any) => u.email === email)) return false;
  users.push({ name, email, password });
  localStorage.setItem("pv-admins", JSON.stringify(users));
  localStorage.setItem("pv-admin-session", JSON.stringify({ email, name }));
  return true;
}
export function adminLogout() {
  localStorage.removeItem("pv-admin-session");
}
export function getAdminSession(): { email: string; name: string } | null {
  if (typeof window === "undefined") return null;
  const s = localStorage.getItem("pv-admin-session");
  return s ? JSON.parse(s) : null;
}
