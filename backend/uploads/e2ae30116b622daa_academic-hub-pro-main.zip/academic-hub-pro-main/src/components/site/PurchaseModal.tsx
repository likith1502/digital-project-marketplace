import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Loader2 } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { addPurchase, type Domain } from "@/lib/data";

export function PurchaseModal({
  domain,
  open,
  onClose,
}: {
  domain: Domain;
  open: boolean;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", mobile: "", college: "", email: "" });
  const [err, setErr] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    if (!form.name.trim()) errors.name = "Required";
    if (!/^\d{10}$/.test(form.mobile.trim())) errors.mobile = "10-digit mobile required";
    if (!form.college.trim()) errors.college = "Required";
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) errors.email = "Invalid email";
    setErr(errors);
    if (Object.keys(errors).length) return;

    setLoading(true);
    setTimeout(() => {
      const txn = "TXN-" + Math.floor(10000 + Math.random() * 89999);
      addPurchase({
        id: "p-" + txn,
        domainId: domain.id,
        domainName: domain.name,
        buyer: form.name,
        mobile: form.mobile,
        college: form.college,
        email: form.email || undefined,
        amount: domain.price,
        status: "paid",
        date: new Date().toISOString().slice(0, 10),
        transactionId: txn,
      });
      onClose();
      navigate({
        to: "/payment-success",
        search: { txn, domain: domain.slug },
      });
    }, 1200);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-foreground/40 backdrop-blur-sm grid place-items-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.96 }}
            transition={{ duration: 0.25, ease: [0.19, 1, 0.22, 1] }}
            className="w-full max-w-lg rounded-lg bg-card border border-border shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between p-6 pb-4">
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-1">
                  Checkout
                </div>
                <h3 className="font-serif text-2xl">Purchase {domain.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Enter your details to receive the download instantly.
                </p>
              </div>
              <button
                onClick={onClose}
                className="grid size-8 place-items-center rounded-full hover:bg-accent text-muted-foreground"
              >
                <X className="size-4" />
              </button>
            </div>

            <form onSubmit={submit} className="px-6 pb-6 space-y-4">
              <Field label="Full Name *" error={err.name}>
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full h-11 px-3 rounded-md border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring/40"
                />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Mobile *" error={err.mobile}>
                  <input
                    inputMode="numeric"
                    value={form.mobile}
                    onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                    className="w-full h-11 px-3 rounded-md border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring/40"
                  />
                </Field>
                <Field label="Email" error={err.email}>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full h-11 px-3 rounded-md border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring/40"
                  />
                </Field>
              </div>
              <Field label="College Name *" error={err.college}>
                <input
                  value={form.college}
                  onChange={(e) => setForm({ ...form, college: e.target.value })}
                  className="w-full h-11 px-3 rounded-md border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring/40"
                />
              </Field>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div>
                  <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Total</div>
                  <div className="text-2xl font-medium">${domain.price.toFixed(2)}</div>
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-sm hover:opacity-90 disabled:opacity-60"
                >
                  {loading ? <Loader2 className="size-4 animate-spin" /> : null}
                  {loading ? "Processing" : "Pay & Download"}
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-1.5">
        {label}
      </div>
      {children}
      {error && <div className="text-xs text-destructive mt-1">{error}</div>}
    </label>
  );
}
