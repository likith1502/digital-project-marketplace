import { Link } from "@tanstack/react-router";
import { ThemeToggle } from "./ThemeToggle";

export function Navbar() {
  return (
    <nav className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <div className="flex items-center gap-8">
          <Link to="/" className="font-serif text-2xl font-semibold italic tracking-tight text-primary">
            ProjectVerse
          </Link>
          <div className="hidden md:flex gap-6 text-sm font-medium text-muted-foreground">
            <Link to="/" activeOptions={{ exact: true }} className="hover:text-foreground transition-colors" activeProps={{ className: "text-foreground" }}>
              Home
            </Link>
            <Link to="/domains" className="hover:text-foreground transition-colors" activeProps={{ className: "text-foreground" }}>
              Explore Domains
            </Link>
            <a href="#how" className="hover:text-foreground transition-colors">How it Works</a>
            <a href="#faq" className="hover:text-foreground transition-colors">FAQ</a>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link
            to="/admin/login"
            className="hidden sm:inline-flex items-center rounded-md bg-foreground px-4 py-2 text-sm font-medium text-background hover:opacity-90 transition-opacity"
          >
            Admin Portal
          </Link>
        </div>
      </div>
    </nav>
  );
}
