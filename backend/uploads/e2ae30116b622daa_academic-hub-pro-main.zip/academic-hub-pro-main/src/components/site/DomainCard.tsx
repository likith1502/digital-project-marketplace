import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { Domain } from "@/lib/data";

export function DomainCard({ d, index = 0 }: { d: Domain; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.05, ease: [0.19, 1, 0.22, 1] }}
      className="group relative border border-border bg-card p-4 rounded-md hover:border-primary/40 transition-colors"
    >
      <div
        className="w-full aspect-[16/10] rounded-sm mb-5 grid place-items-center overflow-hidden relative"
        style={{
          background: `linear-gradient(135deg, color-mix(in oklab, ${d.accent} 18%, transparent), color-mix(in oklab, ${d.accent} 6%, transparent))`,
        }}
      >
        <div className="grain-bg absolute inset-0 opacity-30" />
        <div className="relative font-serif text-3xl italic text-foreground/80 px-6 text-center">
          {d.name}
        </div>
        <div className="absolute top-3 left-3 font-mono text-[10px] tracking-widest uppercase text-foreground/60 bg-background/70 backdrop-blur px-2 py-0.5 rounded-sm">
          {d.category}
        </div>
      </div>
      <div className="px-1 pb-1">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold">{d.name}</h3>
          <span className="font-mono text-xs text-muted-foreground mt-1">
            {String(index + 1).padStart(2, "0")}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mb-6 leading-relaxed line-clamp-2">{d.short}</p>
        <div className="flex items-center justify-between pt-5 border-t border-border">
          <div>
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
              {d.resourceCount} Resources
            </div>
            <div className="text-lg font-medium">${d.price.toFixed(2)}</div>
          </div>
          <Link
            to="/domains/$slug"
            params={{ slug: d.slug }}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-sm hover:opacity-90 transition-opacity"
          >
            Explore
            <ArrowUpRight className="size-3.5" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
