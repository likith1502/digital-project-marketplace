import { Link } from "@tanstack/react-router";

export function Footer() {
  return (
    <footer className="border-t border-border bg-background px-6 py-12 mt-20">
      <div className="mx-auto max-w-7xl grid grid-cols-2 md:grid-cols-4 gap-8">
        <div className="col-span-2">
          <Link to="/" className="font-serif text-2xl italic text-primary">ProjectVerse</Link>
          <p className="mt-3 text-sm text-muted-foreground max-w-sm">
            Premium academic resource bundles curated and delivered instantly. Built for students who value their time.
          </p>
        </div>
        <div>
          <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">Platform</div>
          <ul className="space-y-2 text-sm">
            <li><Link to="/domains" className="hover:text-primary">All Domains</Link></li>
            <li><a href="#faq" className="hover:text-primary">FAQ</a></li>
            <li><a href="#how" className="hover:text-primary">How it Works</a></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">Admin</div>
          <ul className="space-y-2 text-sm">
            <li><Link to="/admin/login" className="hover:text-primary">Admin Login</Link></li>
            <li><Link to="/admin/register" className="hover:text-primary">Register</Link></li>
          </ul>
        </div>
      </div>
      <div className="mx-auto mt-10 max-w-7xl flex flex-col md:flex-row justify-between items-center gap-4 pt-6 border-t border-border">
        <div className="text-xs font-mono text-muted-foreground">© 2026 ProjectVerse Archive. All rights reserved.</div>
        <div className="flex gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
          <a href="#" className="hover:text-primary">Terms</a>
          <a href="#" className="hover:text-primary">Privacy</a>
          <a href="#" className="hover:text-primary">Support</a>
        </div>
      </div>
    </footer>
  );
}
