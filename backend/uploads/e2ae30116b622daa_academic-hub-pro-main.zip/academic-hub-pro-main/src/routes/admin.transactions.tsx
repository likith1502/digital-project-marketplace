import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { getPurchases } from "@/lib/data";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";

export const Route = createFileRoute("/admin/transactions")({
  head: () => ({ meta: [{ title: "Transactions — Admin" }] }),
  component: TxnPage,
});

function TxnPage() {
  const all = useMemo(() => (typeof window === "undefined" ? [] : getPurchases()), []);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<"all" | "paid" | "pending" | "failed">("all");

  const list = all.filter((p) => {
    const matchS = status === "all" || p.status === status;
    const matchQ =
      !q ||
      p.buyer.toLowerCase().includes(q.toLowerCase()) ||
      p.college.toLowerCase().includes(q.toLowerCase()) ||
      p.transactionId.toLowerCase().includes(q.toLowerCase());
    return matchS && matchQ;
  });

  return (
    <AdminShell title="Transactions">
      <div className="mb-6">
        <h1 className="font-serif text-3xl mb-1">Transactions</h1>
        <p className="text-muted-foreground text-sm">
          All purchases across your domain bundles.
        </p>
      </div>

      <div className="flex flex-wrap gap-3 mb-6">
        <div className="flex items-center h-11 bg-card ring-1 ring-border rounded-md px-4 flex-1 max-w-md focus-within:ring-primary">
          <Search className="size-4 text-muted-foreground mr-3" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search buyer, college, transaction ID..."
            className="flex-1 bg-transparent outline-none text-sm"
          />
        </div>
        <div className="flex gap-2">
          {(["all", "paid", "pending", "failed"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`px-3 py-2 text-xs font-mono uppercase tracking-widest rounded-sm border ${
                status === s
                  ? "bg-foreground text-background border-foreground"
                  : "bg-background border-border text-muted-foreground"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="border border-border bg-card rounded-md overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              <th className="text-left px-6 py-3 font-medium">Buyer</th>
              <th className="text-left px-6 py-3 font-medium">College</th>
              <th className="text-left px-6 py-3 font-medium">Domain</th>
              <th className="text-left px-6 py-3 font-medium">Amount</th>
              <th className="text-left px-6 py-3 font-medium">Status</th>
              <th className="text-left px-6 py-3 font-medium">Date</th>
              <th className="text-left px-6 py-3 font-medium">TXN</th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.id} className="border-b border-border last:border-0 hover:bg-accent/30">
                <td className="px-6 py-4">
                  <div className="font-medium">{p.buyer}</div>
                  <div className="text-xs text-muted-foreground">{p.mobile}</div>
                </td>
                <td className="px-6 py-4">{p.college}</td>
                <td className="px-6 py-4">{p.domainName}</td>
                <td className="px-6 py-4 font-medium">${p.amount}</td>
                <td className="px-6 py-4">
                  <span
                    className={`px-2 py-1 rounded-sm font-mono text-[10px] uppercase tracking-widest ${
                      p.status === "paid"
                        ? "bg-primary/15 text-primary"
                        : p.status === "pending"
                          ? "bg-accent text-accent-foreground"
                          : "bg-destructive/15 text-destructive"
                    }`}
                  >
                    {p.status}
                  </span>
                </td>
                <td className="px-6 py-4 font-mono text-xs">{p.date}</td>
                <td className="px-6 py-4 font-mono text-xs">{p.transactionId}</td>
              </tr>
            ))}
            {list.length === 0 && (
              <tr>
                <td colSpan={7} className="text-center py-12 text-muted-foreground">
                  No transactions match your filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
