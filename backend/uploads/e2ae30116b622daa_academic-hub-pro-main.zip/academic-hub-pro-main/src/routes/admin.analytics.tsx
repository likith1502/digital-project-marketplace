import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { DOMAINS, getPurchases } from "@/lib/data";
import { useMemo } from "react";
import {
  BarChart,
  Bar,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

export const Route = createFileRoute("/admin/analytics")({
  head: () => ({ meta: [{ title: "Analytics — Admin" }] }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const purchases = useMemo(() => (typeof window === "undefined" ? [] : getPurchases()), []);
  const paid = purchases.filter((p) => p.status === "paid");
  const revenue = paid.reduce((s, p) => s + p.amount, 0);

  const byDomain = DOMAINS.map((d) => ({
    name: d.name.split(" ")[0],
    value: paid.filter((p) => p.domainId === d.id).reduce((s, p) => s + p.amount, 0) || d.price * 2,
  }));

  const monthly = [
    { m: "Jan", r: 1200 },
    { m: "Feb", r: 1820 },
    { m: "Mar", r: 2400 },
    { m: "Apr", r: 2100 },
    { m: "May", r: 3200 },
    { m: "Jun", r: 4280 },
  ];

  const top = [...DOMAINS]
    .map((d) => ({ ...d, sold: Math.floor(Math.random() * 40) + 5 }))
    .sort((a, b) => b.sold - a.sold)
    .slice(0, 5);

  const COLORS = ["var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)", "var(--color-chart-5)"];

  return (
    <AdminShell title="Analytics">
      <div className="mb-8">
        <h1 className="font-serif text-3xl mb-1">Analytics</h1>
        <p className="text-muted-foreground text-sm">Revenue, downloads and bundle performance.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <StatCard label="Total Revenue" value={`$${revenue.toLocaleString()}`} sub="All time" />
        <StatCard label="Total Downloads" value={paid.length.toString()} sub="Paid orders" />
        <StatCard label="Most Purchased" value={top[0]?.name ?? "—"} sub={`${top[0]?.sold ?? 0} sales`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2 border border-border bg-card rounded-md p-6">
          <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
            Monthly Revenue
          </div>
          <div className="font-serif text-2xl mb-6">Past 6 months</div>
          <div className="h-72">
            <ResponsiveContainer>
              <BarChart data={monthly}>
                <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" />
                <XAxis dataKey="m" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 6,
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="r" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="border border-border bg-card rounded-md p-6">
          <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
            Distribution
          </div>
          <div className="font-serif text-2xl mb-6">By domain</div>
          <div className="h-72">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={byDomain.slice(0, 5)} dataKey="value" innerRadius={50} outerRadius={90}>
                  {byDomain.slice(0, 5).map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="border border-border bg-card rounded-md">
        <div className="p-6 border-b border-border">
          <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Leaderboard
          </div>
          <div className="font-serif text-xl">Top performing domains</div>
        </div>
        <div className="divide-y divide-border">
          {top.map((d, i) => (
            <div key={d.id} className="px-6 py-4 flex items-center gap-4">
              <span className="font-mono text-sm text-muted-foreground w-6">
                {String(i + 1).padStart(2, "0")}
              </span>
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{d.name}</div>
                <div className="text-xs text-muted-foreground">{d.category}</div>
              </div>
              <div className="text-right">
                <div className="font-medium">${(d.sold * d.price).toLocaleString()}</div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  {d.sold} sales
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AdminShell>
  );
}

function StatCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="border border-border bg-card rounded-md p-6">
      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
        {label}
      </div>
      <div className="font-serif text-3xl">{value}</div>
      <div className="text-xs text-muted-foreground mt-1">{sub}</div>
    </div>
  );
}
