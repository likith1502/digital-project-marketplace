import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { PurchaseModal } from "@/components/site/PurchaseModal";
import { getDomainBySlug, DOMAINS } from "@/lib/data";
import { Check, FileText, Download, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";

export const Route = createFileRoute("/domains/$slug")({
  loader: ({ params }) => {
    const d = getDomainBySlug(params.slug);
    if (!d) throw notFound();
    return d;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.name ?? "Domain"} — ProjectVerse` },
      { name: "description", content: loaderData?.short ?? "" },
    ],
  }),
  component: DomainDetail,
  notFoundComponent: () => (
    <div className="min-h-screen grid place-items-center">
      <div className="text-center">
        <h1 className="font-serif text-4xl">Domain not found</h1>
        <Link to="/domains" className="text-primary underline mt-4 inline-block">
          Back to all domains
        </Link>
      </div>
    </div>
  ),
});

function DomainDetail() {
  const d = Route.useLoaderData();
  const [open, setOpen] = useState(false);
  const related = DOMAINS.filter((x) => x.category === d.category && x.id !== d.id).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <section className="border-b border-border px-6 py-10">
        <div className="mx-auto max-w-7xl">
          <Link
            to="/domains"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8"
          >
            <ArrowLeft className="size-4" /> All Domains
          </Link>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="aspect-[4/5] rounded-lg overflow-hidden relative grid place-items-center"
              style={{
                background: `linear-gradient(135deg, color-mix(in oklab, ${d.accent} 22%, transparent), color-mix(in oklab, ${d.accent} 8%, transparent))`,
              }}
            >
              <div className="grain-bg absolute inset-0 opacity-30" />
              <div className="relative font-serif text-5xl md:text-6xl italic text-center text-foreground/80 px-10">
                {d.name}
              </div>
              <div className="absolute top-4 left-4 font-mono text-[10px] uppercase tracking-widest text-foreground/70 bg-background/70 px-2 py-1 rounded-sm">
                {d.category} · {d.resourceCount} Resources
              </div>
            </motion.div>

            <div>
              <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-2">
                Domain Bundle
              </div>
              <h1 className="font-serif text-4xl md:text-5xl tracking-tight mb-4">{d.name}</h1>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">{d.description}</p>

              <div className="space-y-3 mb-8">
                {d.benefits.map((b: string) => (
                  <div key={b} className="flex items-center gap-3">
                    <div className="size-5 rounded-full bg-primary/15 grid place-items-center text-primary shrink-0">
                      <Check className="size-3" />
                    </div>
                    <span className="text-sm">{b}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-border pt-6 flex flex-wrap items-center gap-6">
                <div>
                  <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                    Price
                  </div>
                  <div className="text-4xl font-medium font-serif">${d.price.toFixed(2)}</div>
                </div>
                <div className="border-l border-border pl-6">
                  <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                    Size
                  </div>
                  <div className="text-2xl">{d.sizeGB} GB</div>
                </div>
                <button
                  onClick={() => setOpen(true)}
                  className="ml-auto inline-flex items-center gap-2 px-6 py-3.5 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-sm hover:opacity-90 shadow-lg shadow-primary/20"
                >
                  <Download className="size-4" /> Buy Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-secondary border-b border-border px-6 py-16">
        <div className="mx-auto max-w-7xl grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-2">
              Inside the bundle
            </div>
            <h2 className="font-serif text-3xl mb-6">Files included</h2>
            <div className="bg-background border border-border rounded-md divide-y divide-border">
              {d.files.map((f: {name:string;type:string;size:string}) => (
                <div key={f.name} className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="size-9 rounded bg-primary/10 grid place-items-center text-primary shrink-0">
                      <FileText className="size-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-mono text-sm truncate">{f.name}</div>
                      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                        {f.type} · {f.size}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div className="p-4 text-sm text-muted-foreground font-mono">
                + {d.resourceCount - d.files.length} additional resources inside the ZIP
              </div>
            </div>
          </div>

          <aside className="border border-border bg-background rounded-md p-6 h-fit sticky top-24">
            <div className="font-serif text-xl mb-4">Quick facts</div>
            <Stat label="Resources" value={String(d.resourceCount)} />
            <Stat label="Total Size" value={`${d.sizeGB} GB`} />
            <Stat label="Format" value="ZIP archive" />
            <Stat label="Delivery" value="Instant" />
            <Stat label="Access" value="Lifetime" last />
            <button
              onClick={() => setOpen(true)}
              className="mt-6 w-full px-4 py-3 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-sm hover:opacity-90"
            >
              Buy for ${d.price.toFixed(2)}
            </button>
          </aside>
        </div>
      </section>

      {related.length > 0 && (
        <section className="mx-auto max-w-7xl px-6 py-16">
          <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-2">
            More in {d.category}
          </div>
          <h2 className="font-serif text-3xl mb-8">Related bundles</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {related.map((r, i) => (
              <div key={r.id} className="border border-border bg-card p-5 rounded-md">
                <h3 className="font-serif text-xl mb-2">{r.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{r.short}</p>
                <Link
                  to="/domains/$slug"
                  params={{ slug: r.slug }}
                  className="text-xs font-mono uppercase tracking-widest text-primary hover:underline"
                >
                  Explore →
                </Link>
              </div>
            ))}
          </div>
        </section>
      )}

      <Footer />
      <PurchaseModal domain={d} open={open} onClose={() => setOpen(false)} />
    </div>
  );
}

function Stat({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <div
      className={`flex justify-between items-center py-3 ${last ? "" : "border-b border-border"}`}
    >
      <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </span>
      <span className="text-sm font-medium">{value}</span>
    </div>
  );
}
