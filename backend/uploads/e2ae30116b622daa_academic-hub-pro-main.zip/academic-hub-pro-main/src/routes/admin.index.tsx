import { createFileRoute, Link } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { DOMAINS, getPurchases } from "@/lib/data";
import { useMemo } from "react";
import { DollarSign, Folder, FileText, Download, ArrowUpRight, TrendingUp } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { motion } from "framer-motion";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "Admin Dashboard — ProjectVerse" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  const purchases = useMemo(() => (typeof window === "undefined" ? [] : getPurchases()), []);
  const revenue = purchases.filter((p) => p.status === "paid").reduce((s, p) => s + p.amount, 0);
  const downloads = purchases.filter((p) => p.status === "paid").length;

  const stats = [
    { label: "Revenue", value: `$${revenue.toLocaleString()}`, change: "+12.4%", icon: DollarSign },
    { label: "Total Domains", value: DOMAINS.length, change: "+2", icon: Folder },
    {
      label: "Total Files",
      value: DOMAINS.reduce((s, d) => s + d.resourceCount, 0),
      change: "+38",
      icon: FileText,
    },
    { label: "Downloads", value: downloads, change: "+5", icon: Download },
  ];

  const chartData = [
    { m: "Jan", r: 1240 }, { m: "Feb", r: 1820 }, { m: "Mar", r: 2400 },
    { m: "Apr", r: 2100 }, { m: "May", r: 3200 }, { m: "Jun", r: 4280 },
  ];

  return (
    <AdminShell title="Dashboard">
      <div className="mb-8">
        <h1 className="font-serif text-3xl mb-1">Hi, Admin <span className="italic">👋</span></h1>
        <p className="text-muted-foreground">Here's what's happening with your archive today.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="border border-border bg-card rounded-md p-5"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="size-9 rounded-md bg-primary/10 grid place-items-center text-primary">
                <s.icon className="size-4" />
              </div>
              <span className="text-xs font-mono text-primary flex items-center gap-1">
                <TrendingUp className="size-3" /> {s.change}
              </span>
            </div>
            <div className="text-2xl font-medium font-serif">{s.value}</div>
            <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mt-1">
              {s.label}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2 border border-border bg-card rounded-md p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                Revenue
              </div>
              <div className="font-serif text-2xl">Last 6 months</div>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer>
              <LineChart data={chartData}>
                <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" />
                <XAxis dataKey="m" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 6,
                    fontSize: 12,
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="r"
                  stroke="var(--color-primary)"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: "var(--color-primary)" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="border border-border bg-card rounded-md p-6">
          <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
            Top Domain
          </div>
          <div className="font-serif text-2xl mb-6">Best sellers</div>
          <div className="space-y-4">
            {DOMAINS.slice(0, 5).map((d, i) => (
              <div key={d.id} className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="font-mono text-xs text-muted-foreground w-5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-sm truncate">{d.name}</span>
                </div>
                <span className="text-xs font-medium">${d.price}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="border border-border bg-card rounded-md">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              Activity
            </div>
            <div className="font-serif text-xl">Recent transactions</div>
          </div>
          <Link
            to="/admin/transactions"
            className="text-xs font-mono uppercase tracking-widest text-primary hover:underline inline-flex items-center gap-1"
          >
            View all <ArrowUpRight className="size-3" />
          </Link>
        </div>
        <div className="divide-y divide-border">
          {purchases.slice(0, 5).map((p) => (
            <div key={p.id} className="px-6 py-4 flex items-center justify-between text-sm">
              <div className="min-w-0">
                <div className="font-medium truncate">{p.buyer}</div>
                <div className="text-xs text-muted-foreground truncate">{p.domainName}</div>
              </div>
              <div className="text-right shrink-0">
                <div className="font-medium">${p.amount}</div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  {p.date}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AdminShell>
  );
}
