import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { useState, useRef } from "react";
import { Upload, FileText, Trash2, Edit3 } from "lucide-react";
import { motion } from "framer-motion";

type FileItem = { name: string; size: string; type: string; progress: number };

const initialFiles: FileItem[] = [
  { name: "AI_FinalProject.zip", size: "184 MB", type: "ZIP", progress: 100 },
  { name: "MBA_CaseStudies.pdf", size: "12.4 MB", type: "PDF", progress: 100 },
  { name: "Cyber_Pentest.docx", size: "3.2 MB", type: "DOCX", progress: 100 },
  { name: "Cloud_Architecture.pptx", size: "8.7 MB", type: "PPTX", progress: 100 },
];

export const Route = createFileRoute("/admin/files")({
  head: () => ({ meta: [{ title: "Files — Admin" }] }),
  component: FilesAdmin,
});

function FilesAdmin() {
  const [files, setFiles] = useState<FileItem[]>(initialFiles);
  const [drag, setDrag] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const addFiles = (list: FileList | null) => {
    if (!list) return;
    const newItems: FileItem[] = Array.from(list).map((f) => ({
      name: f.name,
      size: `${(f.size / 1024 / 1024).toFixed(1)} MB`,
      type: f.name.split(".").pop()?.toUpperCase() ?? "FILE",
      progress: 0,
    }));
    setFiles((prev) => [...newItems, ...prev]);
    // simulate progress
    newItems.forEach((nf, idx) => {
      const i = setInterval(() => {
        setFiles((cur) =>
          cur.map((c, j) =>
            j === idx && c.progress < 100 ? { ...c, progress: Math.min(c.progress + 12, 100) } : c,
          ),
        );
      }, 150);
      setTimeout(() => clearInterval(i), 2000);
    });
  };

  return (
    <AdminShell title="Files">
      <div className="mb-6">
        <h1 className="font-serif text-3xl mb-1">File Manager</h1>
        <p className="text-muted-foreground text-sm">
          Upload ZIP, PDF, PPT or DOCX files. Drag and drop supported.
        </p>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          addFiles(e.dataTransfer.files);
        }}
        className={`border-2 border-dashed rounded-md p-12 text-center transition-colors ${
          drag ? "border-primary bg-primary/5" : "border-border bg-card"
        }`}
      >
        <div className="mx-auto size-12 rounded-full bg-primary/10 grid place-items-center text-primary mb-4">
          <Upload className="size-5" />
        </div>
        <div className="font-serif text-xl mb-1">Drop files here</div>
        <div className="text-sm text-muted-foreground mb-4">
          or click to browse · ZIP, PDF, PPT, PPTX, DOC, DOCX
        </div>
        <button
          onClick={() => inputRef.current?.click()}
          className="px-5 py-2 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-md"
        >
          Browse files
        </button>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          accept=".zip,.pdf,.ppt,.pptx,.doc,.docx"
          onChange={(e) => addFiles(e.target.files)}
        />
      </div>

      <div className="mt-8 border border-border bg-card rounded-md overflow-hidden">
        <div className="px-6 py-4 border-b border-border flex items-center justify-between">
          <div className="font-serif text-lg">All Files</div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            {files.length} files
          </div>
        </div>
        <div className="divide-y divide-border">
          {files.map((f, i) => (
            <motion.div
              key={i + f.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="px-6 py-4 flex items-center gap-4"
            >
              <div className="size-10 rounded bg-primary/10 grid place-items-center text-primary shrink-0">
                <FileText className="size-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-mono text-sm truncate">{f.name}</div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  {f.type} · {f.size}
                </div>
                {f.progress < 100 && (
                  <div className="mt-2 h-1 rounded-full bg-secondary overflow-hidden max-w-xs">
                    <div
                      className="h-full bg-primary transition-all"
                      style={{ width: `${f.progress}%` }}
                    />
                  </div>
                )}
              </div>
              <div className="flex gap-1 shrink-0">
                <button className="size-8 grid place-items-center rounded-md hover:bg-accent text-muted-foreground">
                  <Edit3 className="size-3.5" />
                </button>
                <button
                  onClick={() => setFiles((cur) => cur.filter((_, j) => j !== i))}
                  className="size-8 grid place-items-center rounded-md hover:bg-destructive/10 text-destructive"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AdminShell>
  );
}
