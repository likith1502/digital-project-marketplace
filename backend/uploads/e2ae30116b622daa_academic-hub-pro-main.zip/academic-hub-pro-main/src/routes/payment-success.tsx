import { createFileRoute, Link } from "@tanstack/react-router";
import { z } from "zod";
import { motion } from "framer-motion";
import { CheckCircle2, Download, ArrowLeft, FileArchive } from "lucide-react";
import { useState, useEffect } from "react";
import { getDomainBySlug } from "@/lib/data";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";

const searchSchema = z.object({
  txn: z.string().optional(),
  domain: z.string().optional(),
});

export const Route = createFileRoute("/payment-success")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [{ title: "Payment Successful — ProjectVerse" }],
  }),
  component: SuccessPage,
});

function SuccessPage() {
  const { txn, domain } = Route.useSearch();
  const d = domain ? getDomainBySlug(domain) : undefined;
  const [downloading, setDownloading] = useState<"idle" | "starting" | "done">("idle");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (downloading === "starting") {
      const i = setInterval(() => {
        setProgress((p) => {
          if (p >= 100) {
            clearInterval(i);
            setDownloading("done");
            return 100;
          }
          return p + 7;
        });
      }, 120);
      return () => clearInterval(i);
    }
  }, [downloading]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 flex items-center justify-center px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-xl text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
            className="mx-auto mb-6 size-16 rounded-full bg-primary/15 grid place-items-center text-primary"
          >
            <CheckCircle2 className="size-8" />
          </motion.div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-2">
            Payment Confirmed
          </div>
          <h1 className="font-serif text-5xl tracking-tight mb-3">Thank you</h1>
          <p className="text-muted-foreground mb-10">
            Your purchase is complete. The package is ready for download.
          </p>

          <div className="border border-border bg-card rounded-md p-6 text-left space-y-4 mb-8">
            <Row label="Domain" value={d?.name ?? "—"} />
            <Row label="Transaction ID" value={txn ?? "—"} mono />
            <Row label="Amount" value={d ? `$${d.price.toFixed(2)}` : "—"} />
            <Row label="Date" value={new Date().toLocaleDateString()} />
          </div>

          {d && (
            <div className="border border-border bg-card rounded-md p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="size-10 rounded bg-primary/10 grid place-items-center text-primary">
                  <FileArchive className="size-5" />
                </div>
                <div className="text-left min-w-0">
                  <div className="font-mono text-sm truncate">{d.slug}-bundle.zip</div>
                  <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                    ZIP · {d.sizeGB} GB
                  </div>
                </div>
              </div>

              {downloading === "idle" && (
                <button
                  onClick={() => setDownloading("starting")}
                  className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-sm hover:opacity-90"
                >
                  <Download className="size-4" /> Download Package
                </button>
              )}
              {downloading === "starting" && (
                <div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <motion.div
                      className="h-full bg-primary"
                      animate={{ width: `${progress}%` }}
                      transition={{ ease: "linear" }}
                    />
                  </div>
                  <div className="mt-2 text-xs font-mono text-muted-foreground">
                    Downloading... {progress}%
                  </div>
                </div>
              )}
              {downloading === "done" && (
                <div className="text-sm text-primary font-medium">
                  ✓ Downloaded successfully
                </div>
              )}
            </div>
          )}

          <Link
            to="/domains"
            className="mt-10 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-4" /> Browse more domains
          </Link>
        </motion.div>
      </main>
      <Footer />
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </span>
      <span className={`text-sm ${mono ? "font-mono" : ""}`}>{value}</span>
    </div>
  );
}
