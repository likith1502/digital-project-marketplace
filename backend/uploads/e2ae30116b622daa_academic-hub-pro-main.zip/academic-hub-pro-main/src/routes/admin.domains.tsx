import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { DOMAINS } from "@/lib/data";
import { useState } from "react";
import { Pencil, Trash2, Plus, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export const Route = createFileRoute("/admin/domains")({
  head: () => ({ meta: [{ title: "Domains — Admin" }] }),
  component: DomainsAdmin,
});

function DomainsAdmin() {
  const [open, setOpen] = useState(false);
  return (
    <AdminShell title="Domains">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="font-serif text-3xl mb-1">Manage Domains</h1>
          <p className="text-muted-foreground text-sm">
            Create, edit and price your domain bundles.
          </p>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-md"
        >
          <Plus className="size-4" /> New Domain
        </button>
      </div>

      <div className="border border-border bg-card rounded-md overflow-hidden">
        <div className="grid grid-cols-12 px-6 py-3 border-b border-border font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          <div className="col-span-5">Domain</div>
          <div className="col-span-2">Category</div>
          <div className="col-span-2">Resources</div>
          <div className="col-span-2">Price</div>
          <div className="col-span-1 text-right">Actions</div>
        </div>
        {DOMAINS.map((d) => (
          <div
            key={d.id}
            className="grid grid-cols-12 px-6 py-4 border-b border-border last:border-0 items-center hover:bg-accent/30"
          >
            <div className="col-span-5 min-w-0">
              <div className="font-medium truncate">{d.name}</div>
              <div className="text-xs text-muted-foreground truncate">{d.short}</div>
            </div>
            <div className="col-span-2">
              <span className="font-mono text-[10px] uppercase tracking-widest px-2 py-1 rounded-sm bg-secondary">
                {d.category}
              </span>
            </div>
            <div className="col-span-2 text-sm">{d.resourceCount}</div>
            <div className="col-span-2 font-medium">${d.price}</div>
            <div className="col-span-1 flex justify-end gap-1">
              <button className="size-8 grid place-items-center rounded-md hover:bg-accent text-muted-foreground">
                <Pencil className="size-3.5" />
              </button>
              <button className="size-8 grid place-items-center rounded-md hover:bg-destructive/10 text-destructive">
                <Trash2 className="size-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {open && <NewDomainModal onClose={() => setOpen(false)} />}
      </AnimatePresence>
    </AdminShell>
  );
}

function NewDomainModal({ onClose }: { onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm grid place-items-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.96 }}
        className="w-full max-w-lg bg-card border border-border rounded-md shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-widest text-primary">New Entry</div>
            <h3 className="font-serif text-2xl">Create domain</h3>
          </div>
          <button onClick={onClose} className="grid size-8 place-items-center rounded-full hover:bg-accent">
            <X className="size-4" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          {[
            ["Domain Name", "text"],
            ["Short Description", "text"],
            ["Price", "number"],
            ["Resource Count", "number"],
            ["Thumbnail URL", "text"],
          ].map(([label, type]) => (
            <label key={label} className="block">
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-1.5">
                {label}
              </div>
              <input
                type={type as string}
                className="w-full h-11 px-3 rounded-md border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring/40"
              />
            </label>
          ))}
        </div>
        <div className="p-6 border-t border-border flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-mono uppercase tracking-widest rounded-md hover:bg-accent"
          >
            Cancel
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-md"
          >
            Create
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
