import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { DomainCard } from "@/components/site/DomainCard";
import { DOMAINS, CATEGORIES } from "@/lib/data";
import { Search } from "lucide-react";

export const Route = createFileRoute("/domains/")({
  head: () => ({
    meta: [
      { title: "All Domains — ProjectVerse" },
      { name: "description", content: "Browse all academic resource bundles by domain on ProjectVerse." },
    ],
  }),
  component: DomainsPage,
});

function DomainsPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");

  const filtered = DOMAINS.filter((d) => {
    const matchCat = cat === "All" || d.category === cat;
    const matchQ =
      !q ||
      d.name.toLowerCase().includes(q.toLowerCase()) ||
      d.short.toLowerCase().includes(q.toLowerCase());
    return matchCat && matchQ;
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <section className="border-b border-border px-6 py-16">
        <div className="mx-auto max-w-7xl">
          <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-3">
            The Archive · {DOMAINS.length} Domains
          </div>
          <h1 className="font-serif text-5xl md:text-6xl tracking-tight mb-4">
            Explore <span className="italic text-primary">all domains</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl text-lg">
            Every bundle includes projects, notes, PPTs, viva prep and documentation. Filter by category or
            search by keyword.
          </p>

          <div className="mt-10 flex flex-col md:flex-row gap-4 md:items-center">
            <div className="flex items-center h-12 bg-card ring-1 ring-border rounded-md px-4 flex-1 max-w-md focus-within:ring-primary transition-all">
              <Search className="size-4 text-muted-foreground mr-3" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search domains..."
                className="flex-1 bg-transparent outline-none text-sm"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((c) => (
                <button
                  key={c}
                  onClick={() => setCat(c)}
                  className={`px-3 py-2 text-xs font-mono uppercase tracking-widest rounded-sm border transition-colors ${
                    cat === c
                      ? "bg-foreground text-background border-foreground"
                      : "bg-background border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12">
        {filtered.length === 0 ? (
          <div className="text-center py-24 text-muted-foreground">
            <div className="font-serif text-2xl mb-2">Nothing found</div>
            <p>Try a different keyword or category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((d, i) => (
              <DomainCard key={d.id} d={d} index={i} />
            ))}
          </div>
        )}
      </section>
      <Footer />
    </div>
  );
}
