import { createFileRoute } from "@tanstack/react-router";
import { AdminShell } from "@/components/admin/AdminShell";
import { useEffect, useState } from "react";
import { getAdminSession } from "@/lib/data";
import { useTheme } from "@/lib/theme";
import { Sun, Moon, Monitor } from "lucide-react";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({ meta: [{ title: "Settings — Admin" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const [session, setSession] = useState<{ email: string; name: string } | null>(null);
  const [name, setName] = useState("");
  const [siteName, setSiteName] = useState("ProjectVerse");
  const [tagline, setTagline] = useState("Premium Academic Resources");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const s = getAdminSession();
    if (s) {
      setSession(s);
      setName(s.name);
    }
  }, []);

  if (!session) return null;

  return (
    <AdminShell title="Settings">
      <div className="mb-8">
        <h1 className="font-serif text-3xl mb-1">Settings</h1>
        <p className="text-muted-foreground text-sm">
          Manage your profile, theme and website preferences.
        </p>
      </div>

      <div className="max-w-3xl space-y-6">
        <Section title="Profile" desc="Information used across the admin console.">
          <Field label="Full Name">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full h-11 px-3 rounded-md border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring/40"
            />
          </Field>
          <Field label="Email">
            <input
              value={session.email}
              disabled
              className="w-full h-11 px-3 rounded-md border border-input bg-muted text-muted-foreground"
            />
          </Field>
        </Section>

        <Section title="Theme Preference" desc="Choose how the admin console appears.">
          <div className="grid grid-cols-3 gap-3">
            {(
              [
                { v: "light", label: "Light", icon: Sun },
                { v: "dark", label: "Dark", icon: Moon },
                { v: "system", label: "System", icon: Monitor },
              ] as const
            ).map(({ v, label, icon: I }) => (
              <button
                key={v}
                onClick={() => setTheme(v)}
                className={`flex flex-col items-start gap-2 p-4 rounded-md border-2 transition-colors ${
                  theme === v ? "border-primary bg-primary/5" : "border-border hover:bg-accent/30"
                }`}
              >
                <I className="size-4 text-primary" />
                <div className="text-sm font-medium">{label}</div>
              </button>
            ))}
          </div>
        </Section>

        <Section title="Change Password" desc="Update your admin password.">
          <Field label="Current Password">
            <input type="password" className="w-full h-11 px-3 rounded-md border border-input bg-background" />
          </Field>
          <Field label="New Password">
            <input type="password" className="w-full h-11 px-3 rounded-md border border-input bg-background" />
          </Field>
        </Section>

        <Section title="Website Settings" desc="Public-facing site configuration.">
          <Field label="Site Name">
            <input
              value={siteName}
              onChange={(e) => setSiteName(e.target.value)}
              className="w-full h-11 px-3 rounded-md border border-input bg-background"
            />
          </Field>
          <Field label="Tagline">
            <input
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              className="w-full h-11 px-3 rounded-md border border-input bg-background"
            />
          </Field>
        </Section>

        <div className="flex items-center justify-end gap-3 pt-4">
          {saved && (
            <span className="text-sm text-primary font-mono uppercase tracking-widest text-[10px]">
              ✓ Saved
            </span>
          )}
          <button
            onClick={() => {
              setSaved(true);
              setTimeout(() => setSaved(false), 2000);
            }}
            className="px-6 py-2.5 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest rounded-md"
          >
            Save Changes
          </button>
        </div>
      </div>
    </AdminShell>
  );
}

function Section({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="border border-border bg-card rounded-md p-6">
      <div className="mb-5">
        <div className="font-serif text-xl">{title}</div>
        <div className="text-sm text-muted-foreground">{desc}</div>
      </div>
      <div className="space-y-4">{children}</div>
    </div>
  );
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-1.5">
        {label}
      </div>
      {children}
    </label>
  );
}
