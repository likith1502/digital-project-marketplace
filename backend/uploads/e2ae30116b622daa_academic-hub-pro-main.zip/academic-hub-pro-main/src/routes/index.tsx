import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { DomainCard } from "@/components/site/DomainCard";
import { DOMAINS } from "@/lib/data";
import { Search, Zap, ShieldCheck, Download, Quote, ChevronDown } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ProjectVerse — Download Premium Academic Resources Instantly" },
      {
        name: "description",
        content:
          "Curated, domain-specific academic bundles — projects, notes, PPTs, viva questions and documentation. Instant download.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <Hero />
      <FeaturedDomains />
      <HowItWorks />
      <Benefits />
      <Testimonials />
      <FAQ />
      <CTA />
      <Footer />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative px-6 pt-20 pb-24 overflow-hidden">
      <div className="grain-bg absolute inset-0 opacity-40 pointer-events-none" />
      <div className="relative mx-auto max-w-5xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-block mb-6 px-3 py-1 bg-primary/10 rounded-full"
        >
          <span className="font-mono text-[10px] font-medium text-primary tracking-widest uppercase">
            Digital Archive · v2.6
          </span>
        </motion.div>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.19, 1, 0.22, 1] }}
          className="font-serif text-5xl md:text-7xl font-medium tracking-tight text-balance leading-[1.05]"
        >
          Download Premium Academic <br />
          <span className="italic text-primary">Resources Instantly</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mx-auto mt-8 max-w-2xl text-lg text-muted-foreground text-pretty leading-relaxed"
        >
          Projects, Notes, PDFs, PPTs and study resources organized by domain. Curated for students,
          researchers and educators who value their time.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mx-auto mt-10 max-w-2xl"
        >
          <div className="flex items-center h-14 bg-card ring-1 ring-border rounded-lg shadow-sm px-4 focus-within:ring-primary transition-all">
            <Search className="size-4 text-muted-foreground mr-3" />
            <input
              placeholder="Search by domain, topic or file type..."
              className="flex-1 bg-transparent outline-none text-sm"
            />
            <kbd className="hidden sm:inline-flex h-6 items-center gap-1 rounded border border-border bg-secondary px-1.5 font-mono text-[10px] text-muted-foreground">
              ⌘ K
            </kbd>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 flex flex-wrap items-center justify-center gap-x-10 gap-y-3 text-xs font-mono uppercase tracking-widest text-muted-foreground"
        >
          <span>15+ Domains</span>
          <span className="size-1 rounded-full bg-border" />
          <span>2,400+ Resources</span>
          <span className="size-1 rounded-full bg-border" />
          <span>Instant Download</span>
        </motion.div>
      </div>
    </section>
  );
}

function FeaturedDomains() {
  const featured = DOMAINS.slice(0, 6);
  const popular = DOMAINS.slice(6, 9);
  return (
    <>
      <section className="mx-auto max-w-7xl px-6 py-16 border-t border-border">
        <SectionHeader
          eyebrow="Curated Collections"
          title="Featured Domains"
          subtitle="Verified bundles, ready for download."
          link={{ to: "/domains", label: `View all ${DOMAINS.length} domains` }}
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featured.map((d, i) => (
            <DomainCard key={d.id} d={d} index={i} />
          ))}
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-6 py-16 border-t border-border">
        <SectionHeader
          eyebrow="Recently Added"
          title="Fresh from the Archive"
          subtitle="New resource bundles added every month."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popular.map((d, i) => (
            <DomainCard key={d.id} d={d} index={i} />
          ))}
        </div>
      </section>
    </>
  );
}

function SectionHeader({
  eyebrow,
  title,
  subtitle,
  link,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  link?: { to: string; label: string };
}) {
  return (
    <div className="flex items-end justify-between mb-10 flex-wrap gap-4">
      <div>
        <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-2">
          {eyebrow}
        </div>
        <h2 className="font-serif text-3xl md:text-4xl font-medium tracking-tight">{title}</h2>
        <p className="text-muted-foreground mt-2">{subtitle}</p>
      </div>
      {link && (
        <Link to={link.to} className="text-sm font-medium text-primary hover:underline underline-offset-4">
          {link.label} →
        </Link>
      )}
    </div>
  );
}

function HowItWorks() {
  const steps = [
    { n: "01", t: "Browse Domains", d: "Find the academic domain that matches your project or research." },
    { n: "02", t: "Preview Contents", d: "See exactly what's inside — file list, size, and bundle description." },
    { n: "03", t: "Pay Securely", d: "No account needed. Just name, mobile and college to complete checkout." },
    { n: "04", t: "Download Instantly", d: "Get the ZIP archive delivered to your screen the moment payment clears." },
  ];
  return (
    <section id="how" className="bg-secondary border-y border-border py-20 px-6 mt-20">
      <div className="mx-auto max-w-7xl">
        <SectionHeader eyebrow="Process" title="From discovery to download" subtitle="Four steps. No friction." />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-px bg-border">
          {steps.map((s) => (
            <div key={s.n} className="bg-background p-8">
              <div className="font-mono text-xs text-primary tracking-widest mb-6">{s.n}</div>
              <div className="font-serif text-xl mb-2">{s.t}</div>
              <div className="text-sm text-muted-foreground leading-relaxed">{s.d}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Benefits() {
  const items = [
    {
      icon: Zap,
      t: "Instant Delivery",
      d: "Download begins the moment your payment is confirmed. No waiting room.",
    },
    {
      icon: ShieldCheck,
      t: "Verified Quality",
      d: "Each bundle is curated and reviewed before being added to the archive.",
    },
    {
      icon: Download,
      t: "Lifetime Access",
      d: "Buy once, download anytime. Resources never expire from your link.",
    },
  ];
  return (
    <section className="mx-auto max-w-7xl px-6 py-24">
      <SectionHeader eyebrow="Why ProjectVerse" title="Built for serious students" subtitle="Stop scavenging. Start producing." />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {items.map(({ icon: I, t, d }) => (
          <div key={t} className="border border-border bg-card rounded-md p-8">
            <div className="size-10 rounded-md bg-primary/10 grid place-items-center text-primary mb-6">
              <I className="size-5" />
            </div>
            <div className="font-serif text-2xl mb-2">{t}</div>
            <div className="text-sm text-muted-foreground leading-relaxed">{d}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Testimonials() {
  const items = [
    {
      q: "ProjectVerse saved me three weeks of research. The AI bundle came with everything — code, viva prep, even the docs in IEEE format.",
      n: "Ananya S.",
      r: "Final Year, IIT Delhi",
    },
    {
      q: "The MBA pack is genuinely premium. Case studies are well-organized and the financial models actually open in Excel without breaking.",
      n: "Rahul V.",
      r: "MBA Candidate, IIM Bangalore",
    },
    {
      q: "Fast checkout, no signup, instant ZIP. Exactly what I needed two nights before submission.",
      n: "Priya N.",
      r: "B.Tech, NIT Trichy",
    },
  ];
  return (
    <section className="bg-secondary border-y border-border py-20 px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeader eyebrow="Word of Mouth" title="Trusted by students nationwide" subtitle="" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {items.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-background border border-border rounded-md p-8 relative"
            >
              <Quote className="size-6 text-primary/40 mb-4" />
              <p className="font-serif text-lg leading-snug italic mb-6">"{t.q}"</p>
              <div className="pt-4 border-t border-border">
                <div className="font-medium text-sm">{t.n}</div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mt-0.5">
                  {t.r}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const faqs = [
    {
      q: "Do I need to create an account to buy?",
      a: "No account required. Enter your name, mobile and college at checkout — that's it.",
    },
    {
      q: "How is the resource bundle delivered?",
      a: "After payment, you're taken to a success page with an instant download link to a ZIP archive.",
    },
    {
      q: "Can I get a refund if the bundle isn't what I expected?",
      a: "Each bundle page lists its full file contents and size. Because of instant delivery, refunds are reviewed case by case.",
    },
    {
      q: "Are these resources copyright-cleared for academic use?",
      a: "Yes. All bundles are original work curated and contributed by educators and industry mentors.",
    },
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="mx-auto max-w-4xl px-6 py-24">
      <SectionHeader eyebrow="Questions" title="Frequently asked" subtitle="" />
      <div className="border-t border-border">
        {faqs.map((f, i) => (
          <div key={i} className="border-b border-border">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full flex items-center justify-between py-6 text-left hover:text-primary transition-colors"
            >
              <span className="font-serif text-xl">{f.q}</span>
              <ChevronDown
                className={`size-5 shrink-0 transition-transform ${open === i ? "rotate-180" : ""}`}
              />
            </button>
            {open === i && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="pb-6 text-muted-foreground leading-relaxed"
              >
                {f.a}
              </motion.div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-6 pb-8">
      <div className="rounded-lg bg-foreground text-background p-12 md:p-16 relative overflow-hidden">
        <div className="absolute -top-24 -right-24 size-64 bg-primary/30 blur-[100px] pointer-events-none" />
        <div className="relative max-w-2xl">
          <h2 className="font-serif text-4xl md:text-5xl leading-tight mb-4">
            Stop searching. <br />
            <span className="italic opacity-70">Start submitting.</span>
          </h2>
          <p className="opacity-70 mb-8 text-lg">
            Pick a domain bundle. Pay. Download. Get back to actually doing the work.
          </p>
          <Link
            to="/domains"
            className="inline-flex items-center px-6 py-3 bg-background text-foreground text-xs font-bold uppercase tracking-widest rounded-sm hover:opacity-90"
          >
            Browse Domains →
          </Link>
        </div>
      </div>
    </section>
  );
}
